#include "mod.h"

int main(void) {
  led_on();
  led_off();
  return 0;
}


