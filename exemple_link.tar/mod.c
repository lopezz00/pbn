#include <avr/io.h>
#include "mod.h"

void led_on(void) {
  PORTD |= _BV(4);
}


void led_off(void) {
  PORTD &= ~_BV(4);
}



